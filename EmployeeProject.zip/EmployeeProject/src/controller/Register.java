package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connection.Dbconnector;


@WebServlet("/Register")
public class Register extends HttpServlet {
	
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		Connection con2=Dbconnector.getConnection();
		
		String empname=request.getParameter("ename");
		String empid=request.getParameter("eid");
		int eid=Integer.parseInt(empid);
		String eprojectname=request.getParameter("eprojectname");
		
		/* Checking connection */
		if(con2!=null)
		{
			out.println("connected in register servlet");
			String query="insert into register(empname,empid,projectname)"+"values(?,?,?)";
			try {
				PreparedStatement ps=con2.prepareStatement(query);
				ps.setString(1,empname );
				ps.setInt(2, eid);
				ps.setString(3, eprojectname);
				
				ps.execute();
				System.out.println("Insertd successfully!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}else{
			out.println("Not connected");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
