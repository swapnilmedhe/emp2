package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import connection.Dbconnector;

/**
 * Servlet implementation class Display
 */
@WebServlet("/Display")
public class Display extends HttpServlet {
	
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		Connection con=Dbconnector.getConnection();

		if(con != null)
		{
			System.out.println("connected in Display");
			
			
		  try {
			  String query="select * from register ";
			Statement st=con.createStatement();
			ResultSet rs= st.executeQuery(query);
			
			out.println("<table border=1>");
		
			out.print("<tr><th>Empname:</th><th>Empid</th><th>Project</th></tr>");
//			for(int i=1;i<10;i++){
//				rs.next();
//				out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getInt(2)+"</td><td>"+rs.getString(3)+"</td></tr>");
//				
//			}
		//	out.println("<tr><th>Empname:</th><th><input type='text' name='ename' value='"+empName+"'></td></tr><tr><td>Empid</td><td><input type='text' name='eid'></td></tr><tr><td>projectname:</td><td><input type='text' name='eprojectname'></td></tr></tr>");
			while(rs.next())
			{
				out.print("<tr><td>"+rs.getString(1)+"</td><td>"+rs.getInt(2)+"</td><td>"+rs.getString(3)+"</td></tr>");
			}
			
			out.println("</table>");  			
  out.println(rs.getString("empname"));



		

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
