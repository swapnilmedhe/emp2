package model;

public class Employee {
	private String empname;
	private int empid;
	private String projectname;
	
	public String getEmpname() {
		return empname;
	}
	public Employee(String empname, int empid, String projectname) {
		super();
		this.empname = empname;
		this.empid = empid;
		this.projectname = projectname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
